#include <Arduino.h>
#include "ESP32_FX1N.h"
#include "plc_dialogue.h"
#include "plc_io.h"
#include "main.h"
#include "bitoper.h"

/*---------------------------------------------------------------
													  Extern parts
---------------------------------------------------------------*/
extern u8 PLC_FLASH[];
extern u8 PLC_RAM[];
extern void initCrypto();
extern void createTask();
extern void PLC_IO_config(uint16_t _board);
extern void statusRUN(bool _sts,int delay);
extern void initSPIFFS();
extern void PLC_ProInstructParse(void);

/*---------------------------------------------------------------
													  Variable parts
---------------------------------------------------------------*/

/*---------------------------------------------------------------
													  Constant parts
---------------------------------------------------------------*/
//- Ladder task instant
TaskHandle_t t0 = NULL;
const TickType_t xDelay10ms = pdMS_TO_TICKS(10);
const TickType_t xDelay60ms = pdMS_TO_TICKS(60);
const TickType_t xDelay100ms = pdMS_TO_TICKS(100);
const TickType_t xDelay1ms = pdMS_TO_TICKS(1);
const TickType_t xDelay5ms = pdMS_TO_TICKS(5);
const TickType_t xDelay20ms = pdMS_TO_TICKS(20);
const TickType_t xDelay30ms = pdMS_TO_TICKS(30);
const TickType_t xDelay50ms = pdMS_TO_TICKS(50);

/*---------------------------------------------------------------
													System Tasks 
---------------------------------------------------------------*/
void LADDER_Task(void *pvParam){
  while(1){
		PLC_ProInstructParse();																			//- PLC instruction parsing	
    vTaskDelay(xDelay50ms);   																	//- Delay Task ??? 50 ms
  }  
	vTaskDelete(NULL);  
}

/*---------------------------------------------------------------
													  Function parts
---------------------------------------------------------------*/
void initPLC_Internal(uint16_t _board){
  USART1_Configuration();	//- Init USB communication 
  Serial.println();
  Serial.println("Begin set PLC IO");
  PLC_IO_config(_board);        //- Init PLC IO
  Serial.println("Begin PLC Data and Ladder");
  initSPIFFS();	          //- Init SPIFFS
  Serial.println("Init PLC Data");
  data_init();            //- Init PLC Ladder 
  Serial.println("Init PLC Timer");
  PLC_Timer();
  Serial.println("Begin PLC Internal task");
  xTaskCreatePinnedToCore(LADDER_Task,"LADDER_Task",5000,(void*) NULL,1,&t0,1);
  Serial.println("End init All PLC FX1N Configurations");
}

void InitPLC(){
  Serial.begin(19200,SERIAL_7E1);
  initPLC_Internal(0);
}

void InitPLC(uint16_t boardver){
  Serial.begin(19200,SERIAL_7E1);
  initPLC_Internal(boardver);
}

bool getM(uint16_t addr){
  uint16_t _dataPos,data;
	bool ret;

	data = addr + 0x800;
	_dataPos = data/8;
	uint16_t m_data = RAM_16BIT(_dataPos);									//- data address
	uint16_t m_bit = _dataPos%8;														//- data bit
	if((m_data&(1<<m_bit))==(1<<m_bit)){
		return true;
	}else{
		return false;
	}
}

void setM(uint16_t addr,uint8_t pos){
  uint16_t data;
	data = addr + 0x800;
	SETBIT(data,pos);
}

void clearM(uint16_t addr,uint8_t pos){
  uint16_t data;
	data = addr + 0x800;
	CLEARBIT(data,pos);
}

uint8_t getU8D(uint16_t addr){
  return RAM_8BIT(0x3000+addr*2);
}

uint16_t getU16D(uint16_t addr){
  if(addr >= 8000){
    return RAM_16BIT(0x0E00+addr*2);
  }else{
    return RAM_16BIT(0x3000+addr*2);
  }
}

uint32_t getU32D(uint16_t addr){
  return RAM_32BIT(0x3000+addr*2);
}

uint16_t getT(uint16_t _t){
  return RAM_16BIT(0x1000+_t*2);
}

uint16_t getC(uint16_t C_number){
  return RAM_16BIT(0x2000+C_number*2);
}

float getFD(uint16_t addr){
  return RAM_32BITF(0x3000+addr*2);
}

void setU8D(uint16_t addr,uint8_t val){
  RAM_8BIT(0x3000+addr*2) = val;
}

void setU16D(uint16_t addr,uint16_t val){
  RAM_16BIT(0x3000+addr*2) = val;
}

void setU32D(uint16_t addr,uint32_t val){
  RAM_32BIT(0x3000+addr*2) = val;
}

void setFD(uint16_t addr,float val){
  RAM_32BITF(0x3000+addr*2) = val;
}